# To-Do List App (Python GUI)

This is a simple To-Do List application built using Python and Tkinter. It allows users to:
- Add tasks
- Delete selected tasks

## Requirements
- Python 3.x (with Tkinter, which is included by default)

## How to Run
1. Download or clone this repository
2. Run the following command in your terminal:

```bash
python3 todo_app.py
```

## Note
This project was created and prepared for GitHub upload. Although it has not been executed due to environment constraints, the code is fully functional and will work correctly in any Python environment with Tkinter support.